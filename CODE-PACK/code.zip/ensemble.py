from keras import backend as keras_back
from keras.layers import Input
import tensorflow as tf

from effnet import get_model_effnet
from resnet import get_model_resnet
from utils.utils import get_callbacks
import numpy as np


def get_model_ensemble(x_data, weights, resnet_depth, effnet_version):
    # TODO Testando comentar esse trecho..
    # keras_back.set_image_data_format('channels_last')
    # img_shape = (x_data.shape[1], x_data.shape[2], x_data.shape[3])
    # print("Input Shape Matrix: ", img_shape)
    # print("X_data Shape: 1- {}, 2- {}, 3- {}".format(x_data.shape[1], x_data.shape[2], x_data.shape[3]))
    # img_input = Input(shape=img_shape)

    print('\n ** Utilizando o Ensemble das redes Resnet{}, EfficientNet{}'.format(resnet_depth, effnet_version))
    print('\n ** Pesos carregados: ', weights)

    # TODO TESTE MUDANDO O x_data

    x_data_len = int((len(x_data))/2)

    x_data_resnet = x_data[:x_data_len, :]
    # np.random.shuffle(x_data)
    # x_data_resnet = x_data
    # np.random.shuffle(x_data)
    x_data_effnet = x_data[x_data_len:, :]
    # x_data_effnet = x_data

    print('\n ** Misturando os dados no Ensemble')
    print('\n ** x_data_resnet: ', x_data_resnet.shape)
    print('\n ** x_data_effnet: ', x_data_effnet.shape)

    # *** Resnet = model_1
    # model_resnet = get_model_resnet(x_data, weights, resnet_depth)
    model_resnet = get_model_resnet(x_data_resnet, weights, resnet_depth)
    print('\n ** Modelo Ensemble Resnet Criado!')
    # print('\n', model_resnet.summary(), '\n\n')

    # EfficientNet = model_2
    # model_effnet = get_model_effnet(x_data, weights, effnet_version)
    model_effnet = get_model_effnet(x_data_effnet, weights, effnet_version)
    print('\n ** Modelo Ensemble Efficient Net Criado!')
    # print('\n', model_effnet.summary(), '\n\n')

    # models = [model_resnet, model_effnet]
    # TODO INVERTENDO A ORDEM DE TREINAMENTO DAS REDES
    # models = [model_effnet, model_resnet]

    # return models
    return [model_resnet, model_effnet]


def compile_model_ensemble(name_file_rede, model_resnet, model_effnet, opt, fold):
    print('\n Compilando rede: ', name_file_rede)

    print('\n ** Plotting model and callbacks Resnet...')
    model_resnet.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
    name_weights_resnet = 'Train_model_weights_%s_resnet_{epoch:02d}.h5' % name_file_rede
    csv_name_resnet = 'training_{}_resnet_fold_{}.csv'.format(name_file_rede, fold)
    callbacks_resnet = get_callbacks(name_weights=name_weights_resnet, patience_lr=10, name_csv=csv_name_resnet)

    print('\n ** Plotting model and callbacks Efficient Net...')
    model_effnet.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
    name_weights_efn = 'Train_model_weights_%s_effnet_{epoch:02d}.h5' % name_file_rede
    csv_name_efn = 'training_{}_effnet_fold_{}.csv'.format(name_file_rede, fold)
    callbacks_efn = get_callbacks(name_weights=name_weights_efn, patience_lr=10, name_csv=csv_name_efn)

    # TODO INVERTENDO A ORDEM DE TREINAMENTO DAS REDES

    # print('\n ** Plotting model and callbacks Efficient Net...')
    # model_effnet.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
    # name_weights_efn = 'Train_model_weights_%s_effnet_{epoch:02d}.h5' % name_file_rede
    # csv_name_efn = 'training_{}_effnet_fold_{}.csv'.format(name_file_rede, fold)
    # callbacks_efn = get_callbacks(name_weights=name_weights_efn, patience_lr=10, name_csv=csv_name_efn)
    #
    # print('\n ** Plotting model and callbacks Resnet...')
    # model_resnet.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
    # name_weights_resnet = 'Train_model_weights_%s_resnet_{epoch:02d}.h5' % name_file_rede
    # csv_name_resnet = 'training_{}_resnet_fold_{}.csv'.format(name_file_rede, fold)
    # callbacks_resnet = get_callbacks(name_weights=name_weights_resnet, patience_lr=10,
    #                                  name_csv=csv_name_resnet)

    return [callbacks_resnet, callbacks_efn]


def fit_model_ensemble(model_resnet, model_effnet, generator, x_data_cv, batch_size, num_epochs, x_val_cv, y_val_cv, callbacks_resnet, callbacks_efn):

    print('\n ** Fit Rede Resnet')
    history_resnet = model_resnet.fit_generator(
        generator,
        steps_per_epoch=len(x_data_cv) / batch_size,
        epochs=num_epochs,
        verbose=1,
        validation_data=(x_val_cv, y_val_cv),
        validation_steps=len(x_val_cv) / batch_size,
        callbacks=callbacks_resnet)

    print('\n ** Fit Rede EfficientNet')
    history_efn = model_effnet.fit_generator(
        generator,
        steps_per_epoch=len(x_data_cv) / batch_size,
        epochs=num_epochs,
        verbose=1,
        validation_data=(x_val_cv, y_val_cv),
        validation_steps=len(x_val_cv) / batch_size,
        callbacks=callbacks_efn)
    # history = [history_resnet, history_efn]

    # TODO INVERTENDO A ORDEM DE TREINAMENTO DAS REDES

    # print('\n ** Fit Rede EfficientNet')
    # history_efn = model_effnet.fit_generator(
    #     generator,
    #     steps_per_epoch=len(x_data_cv) / batch_size,
    #     epochs=num_epochs,
    #     verbose=1,
    #     validation_data=(x_val_cv, y_val_cv),
    #     validation_steps=len(x_val_cv) / batch_size,
    #     callbacks=callbacks_efn)
    #
    # print('\n ** Fit Rede Resnet')
    # history_resnet = model_resnet.fit_generator(
    #     generator,
    #     steps_per_epoch=len(x_data_cv) / batch_size,
    #     epochs=num_epochs,
    #     verbose=1,
    #     validation_data=(x_val_cv, y_val_cv),
    #     validation_steps=len(x_val_cv) / batch_size,
    #     callbacks=callbacks_resnet)

    return [history_resnet, history_efn]

