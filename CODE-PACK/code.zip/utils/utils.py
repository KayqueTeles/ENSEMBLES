import numpy as np
from sklearn.model_selection import StratifiedKFold
from keras.callbacks import ModelCheckpoint, ReduceLROnPlateau, CSVLogger
from keras.optimizers import SGD
from keras.optimizers import Adam
from sklearn.metrics import roc_auc_score
from sklearn import metrics


# Separa os conjuntos de treino, teste e validação.
def test_samples_balancer(y_data, x_data, vallim, train_size, test_peq, test_size):
    y_size = len(y_data)
    y_yes, y_no, y_excess = ([] for i in range(3))
    e_lente = 0
    n_lente = 0
    # range(start, stop, step) - (início do intervalo, fim, o quanto aumenta em cada loop)
    for y in range(0, y_size, 1):
        if y_data[y] == 1:
            # Pegamos uma quantidade de dados para treino e o que sobra vai para o excess e é usado para validação/teste
            e_lente += 1
            if len(y_yes) < (train_size * 5):
                # Armazenamos os índices
                y_yes = np.append(int(y), y_yes)
            else:
                y_excess = np.append(int(y), y_excess)
        else:
            n_lente += 1
            if len(y_no) < (train_size * 5):
                y_no = np.append(int(y), y_no)
            else:
                y_excess = np.append(int(y), y_excess)

    print('\n Casos lente = ', e_lente)
    print('\n Casos nao lente = ', n_lente)
    y_y = np.append(y_no, y_yes)
    np.random.shuffle(y_y)

    np.random.shuffle(y_excess)
    y_y = y_y.astype(int)
    y_excess = y_excess.astype(int)

    # Define o tamanho do conjunto de validação, utilizando a variável vallim (nesse caso 2.000)
    y_val = y_data[y_excess[0:vallim]]
    x_val = x_data[y_excess[0:vallim]]

    # TODO - Diminuir a quantidade de dados
    # test_peq = True
    # test_peq = False

    if test_peq:
        print('Realizando testes com dados reduzidos. Dados de teste = ', test_size)
        y_test = y_data[y_excess[vallim:int(vallim + test_size)]]
        x_test = x_data[y_excess[vallim:int(vallim + test_size)]]

    else:
        y_test = y_data[y_excess[vallim:int(len(y_excess))]]
        x_test = x_data[y_excess[vallim:int(len(y_excess))]]
        print('Realizando testes com conjunto normal de dados. Dados de teste = ', len(x_test))

    # Preenchemos o y_data, usando os índices criados no y_y
    y_data = y_data[y_y]
    x_data = x_data[y_y]

    return [y_data, x_data, y_test, x_test, y_val, x_val]


# Randomiza os dados para divisão nas folds
def load_data_kfold(k, x_data, y_data):
    print('Preparing Folds')
    folds = list(StratifiedKFold(n_splits=k, shuffle=True, random_state=1).split(x_data, y_data))

    return folds


def get_callbacks(name_weights, patience_lr, name_csv):
    mcp_save = ModelCheckpoint(name_weights)
    csv_logger = CSVLogger(name_csv)
    reduce_lr_loss = ReduceLROnPlateau(monitor='loss', factor=0.1, patience=patience_lr, verbose=1, epsilon=1e-4,
                                       mode='max')
    return [mcp_save, csv_logger, reduce_lr_loss]


def select_optimizer(optimizer, learning_rate):
    if optimizer == 'sgd':
        print('\n ** Usando otimizador: ', optimizer)
        opt = SGD(lr=learning_rate, decay=1e-6, momentum=0.9, nesterov=True)

    else:
        print('\n ** Usando otimizador: ', optimizer)
        opt = Adam(learning_rate=learning_rate)
    return opt


# Gera a curva ROC
def roc_curve_calculate(y_test, x_test, model, rede):
    print('Roc Curve Calculating')
    if rede == 'ensemble':
        print('\n ** Preds: ', rede)
        resnet = model[0]
        efn = model[1]

        prob_resnet = resnet.predict(x_test)
        prob_efn = efn.predict(x_test)

        print('\n ** prob_resnet: ', prob_resnet)
        print('\n ** prob_efn: ', prob_efn)

        probs = (prob_resnet + prob_efn) / 2
        print('\n ** probs_ensemble: ', probs)

    else:
        print('\n ** Preds: ', rede)
        probs = model.predict(x_test)
        print('\n ** probs: ', probs)
        print('\n ** probs.shape: ', probs.shape)

    probsp = probs[:, 1]
    # print('\n ** probsp: ', probsp)
    # print('\n ** probsp.shape: ', probsp.shape)
    y_new = y_test[:, 1]
    print('\n ** y_new: ', y_new)
    thres = 1000

    threshold_v = np.linspace(1, 0, thres)
    tpr, fpr = ([] for i in range(2))

    for tt in range(0, len(threshold_v), 1):
        thresh = threshold_v[tt]
        tp_score, fp_score, tn_score, fn_score = (0 for i in range(4))
        for xz in range(0, len(probsp), 1):
            if probsp[xz] > thresh:
                if y_new[xz] == 1:
                    tp_score = tp_score + 1
                else:
                    fp_score = fp_score + 1
            else:
                if y_new[xz] == 0:
                    tn_score = tn_score + 1
                else:
                    fn_score = fn_score + 1
        tp_rate = tp_score / (tp_score + fn_score)
        fp_rate = fp_score / (fp_score + tn_score)
        tpr.append(tp_rate)
        fpr.append(fp_rate)

    auc2 = roc_auc_score(y_test[:, 1], probsp)
    auc = metrics.auc(fpr, tpr)

    print('\n ** AUC (via metrics.auc): {}, AUC (via roc_auc_score): {}'.format(auc, auc2))
    # print('\n ** TP_Rate: {}'.format(tpr))
    # print('\n ** FP_Rate: {}'.format(fpr))
    # print('\n ** AUC: {}'.format(auc))
    # print('\n ** AUC2: {}'.format(auc2))
    # print('\n ** Thresh: {}'.format(thres))

    return [tpr, fpr, auc, auc2, thres]


def roc_curve_calculate_ensemble(y_test, x_test, model_resnet, model_effnet, rede):
    print('Roc Curve Calculating')
    print('\n ** Preds: ', rede)
    # resnet = model[0]
    # efn = model[1]

    prob_resnet = model_resnet.predict(x_test)
    prob_efn = model_effnet.predict(x_test)
    print(" ** There goes the Probabilities vector:")
    print(" ** Resnet:")
    print(prob_resnet)
    print(" ** EfficientNet:")
    print(prob_efn)

    with open('ensemble_data_%s.csv' % version, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(prob_resnet[:,1], prob_efn[:,1])
        #writer.writerows(code_data)

    # print('\n ** prob_resnet: ', prob_resnet)
    # print('\n ** prob_efn: ', prob_efn)

    probs = (prob_resnet + prob_efn) / 2
    print('\n ** probs_ensemble: ', probs)

    probsp = probs[:, 1]
    # print('\n ** probsp: ', probsp)
    # print('\n ** probsp.shape: ', probsp.shape)
    y_new = y_test[:, 1]
    # print('\n ** y_new: ', y_new)
    thres = 1000

    threshold_v = np.linspace(1, 0, thres)
    tpr, fpr = ([] for i in range(2))

    for tt in range(0, len(threshold_v), 1):
        thresh = threshold_v[tt]
        tp_score, fp_score, tn_score, fn_score = (0 for i in range(4))
        for xz in range(0, len(probsp), 1):
            if probsp[xz] > thresh:
                if y_new[xz] == 1:
                    tp_score = tp_score + 1
                else:
                    fp_score = fp_score + 1
            else:
                if y_new[xz] == 0:
                    tn_score = tn_score + 1
                else:
                    fn_score = fn_score + 1
        tp_rate = tp_score / (tp_score + fn_score)
        fp_rate = fp_score / (fp_score + tn_score)
        tpr.append(tp_rate)
        fpr.append(fp_rate)

    auc2 = roc_auc_score(y_test[:, 1], probsp)
    auc = metrics.auc(fpr, tpr)

    print('\n ** AUC (via metrics.auc): {}, AUC (via roc_auc_score): {}'.format(auc, auc2))
    # print('\n ** TP_Rate: {}'.format(tpr))
    # print('\n ** FP_Rate: {}'.format(fpr))
    # print('\n ** AUC: {}'.format(auc))
    # print('\n ** AUC2: {}'.format(auc2))
    # print('\n ** Thresh: {}'.format(thres))

    return [tpr, fpr, auc, auc2, thres]


def acc_score(acc0, history, val_acc0, loss0, val_loss0):
    print('\n ** Calculating acc0, val_acc0, loss0, val_loss0')
    acc0 = np.append(acc0, history.history['accuracy'])
    val_acc0 = np.append(val_acc0, history.history['val_accuracy'])
    loss0 = np.append(loss0, history.history['loss'])
    val_loss0 = np.append(val_loss0, history.history['val_loss'])
    print('\n ** Finished Calculating!')

    return [acc0, val_acc0, loss0, val_loss0]


def acc_score_ensemble(acc0, history, val_acc0, loss0, val_loss0):
    print('\n ** Calculating acc0, val_acc0, loss0, val_loss0')
    acc0 = np.append(acc0, history.history['accuracy'])
    val_acc0 = np.append(val_acc0, history.history['val_accuracy'])
    loss0 = np.append(loss0, history.history['loss'])
    val_loss0 = np.append(val_loss0, history.history['val_loss'])
    print('\n ** Finished Calculating!')

    return [acc0, val_acc0, loss0, val_loss0]


def define_nomes_redes(rede, resnet_depth, effnet_version):
    if rede == 'resnet':
        title_graph_rede = 'Resnet' + str(resnet_depth)
        name_file_rede = rede + str(resnet_depth)
    elif rede == 'effnet':
        title_graph_rede = 'EfficientNet' + effnet_version
        name_file_rede = rede + effnet_version
    else:
        title_graph_rede = 'Ensemble'
        name_file_rede = 'ensemble'

    return [title_graph_rede, name_file_rede]


def nomes_extra_ensenble():
    title_graph_rede_resnet = 'Ensemble Resnet'
    name_file_rede_resnet = 'ensemble_resnet'
    title_graph_rede_effnet = 'Ensemble Efficient Net'
    name_file_rede_effnet = 'ensemble_effnet'

    return [title_graph_rede_resnet, name_file_rede_resnet, title_graph_rede_effnet, name_file_rede_effnet]
