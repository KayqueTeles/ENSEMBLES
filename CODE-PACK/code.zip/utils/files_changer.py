import os
import shutil
import tarfile
import zipfile
import wget

path_folder = '/home/kayque/LENSLOAD/results'
# path_folder = 'C:/Users/Teletrabalho/Documents/Pessoal/resultados'
# path_folder = '/home/hdd2T/icaroDados'


# Método que faz o download do dataset, se necessário
def data_downloader():
    if os.path.exists('./lensdata/x_data20000fits.h5'):
        print(' ** Files from lensdata.tar.gz were already downloaded.')
    else:
        print('\n ** Downloading lensdata.zip...')
        wget.download('https://clearskiesrbest.files.wordpress.com/2019/02/lensdata.zip')
        print(' ** Download successful. Extracting...')
        with zipfile.ZipFile('lensdata.zip', 'r') as zip_ref:
            zip_ref.extractall()
            print(' ** Extracted successfully.')
        print(' ** Extracting data from lensdata.tar.gz...')
        tar = tarfile.open('lensdata.tar.gz', 'r:gz')
        tar.extractall()
        tar.close()
        print(' ** Extracted successfully.')

    if os.path.exists('./lensdata/x_data20000fits.h5'):
        print(' ** Files from lensdata.tar.gz were already extracted.')
    else:
        print(' ** Extracting data from #DataVisualization.tar.gz...')
        tar = tarfile.open('./lensdata/DataVisualization.tar.gz', 'r:gz')
        tar.extractall('./lensdata/')
        tar.close()
        print(' ** Extracted successfully.')
        print(' ** Extrating data from x_data20000fits.h5.tar.gz...')
        tar = tarfile.open('./lensdata/x_data20000fits.h5.tar.gz', 'r:gz')
        tar.extractall('./lensdata/')
        tar.close()
        print(' ** Extracted successfully.')
    if os.path.exists('lensdata.tar.gz'):
        os.remove('lensdata.tar.gz')
    if os.path.exists('lensdata.zip'):
        os.remove('lensdata.zip')

    for pa in range(0, 10, 1):
        if os.path.exists('lensdata ({}).zip'. format(pa)):
            os.remove('lensdata ({}).zip'. format(pa))


# Método que elimina arquivos de testes anteriores
def file_remover(train_size, k_folds, version, name_file_rede, num_epochs):
    piccounter, weicounter, csvcounter = (0 for i in range(3))
    print('\n ** Removing specified files and folders...')
    print(' ** Checking .png, .h5 and csv files...')
    # for fold in range(0, 10 * k_folds, 1):
    for fold in range(0, k_folds, 1):
        # fig.savefig('TrainTest_rate_{}_TR_{}.png'. format(name_file_rede, train_size))
        if os.path.exists('./TrainTest_rate_{}_TR_{}.png'. format(name_file_rede, train_size)):
            os.remove('./TrainTest_rate_{}_TR_{}.png'. format(name_file_rede, train_size))
            piccounter = piccounter + 1
        # fig.savefig('TrainVal_rate_{}_TR_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
        if os.path.exists('./TrainVal_rate_{}_TR_{}_Fold_{}.png'. format(name_file_rede, train_size, fold)):
            os.remove('./TrainVal_rate_{}_TR_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
            piccounter = piccounter + 1
        # plt.savefig('AccxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
        if os.path.exists('./AccxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold)):
            os.remove('./AccxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
            piccounter = piccounter + 1
        # plt.savefig('LossxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
        if os.path.exists('./LossxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold)):
            os.remove('./LossxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
            piccounter = piccounter + 1
        # plt.savefig('ROCLensDetectNet_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
        if os.path.exists('./ROCLensDetectNet_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold)):
            os.remove('./ROCLensDetectNet_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
            piccounter = piccounter + 1
        # plt.savefig('ROCLensDetectNet_{}_Full_{}.png'. format(name_file_rede, train_size))
        if os.path.exists('./ROCLensDetectNet_{}_Full_{}.png'. format(name_file_rede, train_size)):
            os.remove('./ROCLensDetectNet_{}_Full_{}.png'. format(name_file_rede, train_size))
            piccounter = piccounter + 1
        # plt.savefig('AUCxSize_{}.png'. format(name_file_rede))
        if os.path.exists('./AUCxSize_{}.png'. format(name_file_rede)):
            os.remove('./AUCxSize_{}.png'. format(name_file_rede))
            piccounter = piccounter + 1
        # csv_name = 'training_{}_fold_{}.csv'. format(name_file_rede, fold) -- Resnet e Effnet
        if os.path.exists('training_{}_fold_{}.csv'. format(name_file_rede, fold)):
            os.remove('training_{}_fold_{}.csv'. format(name_file_rede, fold))
            csvcounter = csvcounter + 1
        # csv_name_resnet = 'training_{}_resnet_fold_{}.csv'. format(name_file_rede, fold)
        if os.path.exists('training_{}_resnet_fold_{}.csv'. format(name_file_rede, fold)):
            os.remove('training_{}_resnet_fold_{}.csv'. format(name_file_rede, fold))
            csvcounter = csvcounter + 1
        # csv_name_efn = 'training_{}_effnet_fold_{}.csv'. format(name_file_rede, fold)
        if os.path.exists('training_{}_effnet_fold_{}.csv'. format(name_file_rede, fold)):
            os.remove('training_{}_effnet_fold_{}.csv'. format(name_file_rede, fold))
            csvcounter = csvcounter + 1

    # for (epoch = 0  epoch):
    for epoch in range(0, num_epochs, 1):
        # name_weights = 'Train_model_weights_%s_{epoch:02d}.h5' % name_file_rede
        # print('\n ** Removing WEIGHTS: ' 'Train_model_weights_{}_0{}.h5'. format(name_file_rede, epoch + 1))

        # TODO - TESTE remover com if emsemble
        if name_file_rede == 'ensemble':
            weicounter = remove_weights_ensemble(weicounter, name_file_rede, epoch)
        # Números menores que 10
        if os.path.exists('Train_model_weights_{}_0{}.h5'. format(name_file_rede, epoch + 1)):
            os.remove('Train_model_weights_{}_0{}.h5'. format(name_file_rede, epoch + 1))
            weicounter = weicounter + 1
        # Números maiores que 10
        elif os.path.exists('Train_model_weights_{}_{}.h5'. format(name_file_rede, epoch + 1)):
            os.remove('Train_model_weights_{}_{}.h5'. format(name_file_rede, epoch + 1))
            weicounter = weicounter + 1

    # if os.path.exists('/home/dados2T/icaroDados/resnetLens/results/RNCV_%s_%s/' % (version, train_size)):
    if os.path.exists('{}_{}_{}/'. format(name_file_rede, version, train_size)):
        shutil.rmtree('{}_{}_{}/'. format(name_file_rede, version, train_size))

    print('\n ** Done. {} .png files removed, {} .h5 files removed and {} .csv removed.'. format(piccounter, weicounter, csvcounter))


def filemover(train_size, version, k_folds, name_file_rede, title_graph_rede, num_epochs):
    # Checando se as pastas já existem, e apagando ou criando, de acordo com o caso
    print('\n ** Moving created files to a certain folder.')
    counter = 0

    print(" ** Checking if there's a results folder...")
    if os.path.exists('./results'):
        print(' ** results fwriter.writerowile found. Moving forward.')
    else:
        print(' ** None found. Creating one.')
        os.mkdir('./results')
        print(' ** Done!')

    # print(" ** Checking if there's an RNCV folder...")
    print(" ** Checking if there's an network({}) folder...". format(title_graph_rede))
    # if os.path.exists('/home/dados2T/icaroDados/resnetLens/results/RNCV_%s_%s/' % (version, train_size)):
    if os.path.exists('./results/{}_{}_{}/'. format(name_file_rede, version, train_size)):
        # if os.path.exists('results/RNCV_%s_%s' % (version, train_size)):
        print(' ** Yes. There is. Trying to delete and renew...')
        shutil.rmtree('./results/{}_{}_{}/'. format(name_file_rede, version, train_size))
        # shutil.rmtree('results/RNCV_%s_%s' % (version, TR))
        os.mkdir('./results/{}_{}_{}/'. format(name_file_rede, version, train_size))
        # os.mkdir('results/RNCV_%s_%s' % (version, TR))
        print(' ** Done!')
    else:
        print(' ** None found. Creating one.')
        # os.mkdir('results')
        os.mkdir('./results/{}_{}_{}/'. format(name_file_rede, version, train_size))
        # os.mkdir('results/RNCV_%s_%s' % (version, TR))
        print(' ** Done!')

        # dest1 = ('/home/kayque/LENSLOAD/results/RNCV_%s_%s/' % (version, TR))
        dest1 = ('{}/{}_{}_{}/'. format(path_folder, name_file_rede, version, train_size))

    # Variável contador de weights removidos
    weicounter = 0

    # Movendo os arquivos criados na execução do teste
    for fold in range(0, 10 * k_folds, 1):
        # fig.savefig('TrainTest_rate_{}_TR_{}.png'. format(name_file_rede, train_size))
        if os.path.exists('./TrainTest_rate_{}_TR_{}.png'. format(name_file_rede, train_size)):
            shutil.move('./TrainTest_rate_{}_TR_{}.png'. format(name_file_rede, train_size), dest1)
            counter = counter + 1
        # fig.savefig('TrainVal_rate_{}_TR_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
        if os.path.exists('./TrainVal_rate_{}_TR_{}_Fold_{}.png'. format(name_file_rede, train_size, fold)):
            shutil.move('./TrainVal_rate_{}_TR_{}_Fold_{}.png'. format(name_file_rede, train_size, fold), dest1)
            counter = counter + 1
        # plt.savefig('AccxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
        if os.path.exists('./AccxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold)):
            shutil.move('./AccxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold), dest1)
            counter = counter + 1
        # plt.savefig('LossxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
        if os.path.exists('./LossxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold)):
            shutil.move('./LossxEpoch_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold), dest1)
            counter = counter + 1
        # plt.savefig('ROCLensDetectNet_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold))
        if os.path.exists('./ROCLensDetectNet_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold)):
            shutil.move('./ROCLensDetectNet_{}_{}_Fold_{}.png'. format(name_file_rede, train_size, fold), dest1)
            counter = counter + 1
        # plt.savefig('ROCLensDetectNet_{}_Full_{}.png'. format(name_file_rede, train_size))
        if os.path.exists('./ROCLensDetectNet_{}_Full_{}.png'. format(name_file_rede, train_size)):
            shutil.move('./ROCLensDetectNet_{}_Full_{}.png'. format(name_file_rede, train_size), dest1)
            counter = counter + 1
        # plt.savefig('AUCxSize_{}.png'. format(name_file_rede))
        if os.path.exists('./AUCxSize_{}.png'. format(name_file_rede)):
            shutil.move('./AUCxSize_{}.png'. format(name_file_rede), dest1)
            counter = counter + 1
        # csv_name = 'training_{}_fold_{}.csv'. format(name_file_rede, fold) -- Resnet e Effnet
        if os.path.exists('training_{}_fold_{}.csv'. format(name_file_rede, fold)):
            shutil.move('training_{}_fold_{}.csv'. format(name_file_rede, fold), dest1)
            counter = counter + 1
        # csv_name_resnet = 'training_{}_resnet_fold_{}.csv'. format(name_file_rede, fold)
        if os.path.exists('training_{}_resnet_fold_{}.csv'. format(name_file_rede, fold)):
            shutil.move('training_{}_resnet_fold_{}.csv'. format(name_file_rede, fold), dest1)
            counter = counter + 1
        # csv_name_efn = 'training_{}_effnet_fold_{}.csv'. format(name_file_rede, fold)
        if os.path.exists('training_{}_effnet_fold_{}.csv'. format(name_file_rede, fold)):
            shutil.move('training_{}_effnet_fold_{}.csv'. format(name_file_rede, fold), dest1)
            counter = counter + 1
        if os.path.exists('ensemble_data_{}.csv'. format(version)):
            shutil.move('ensemble_data_{}.csv'. format(version), dest1)
            counter = counter + 1
        if os.path.exists('code_data_version_{}_.csv'. format(version)):
            shutil.move('ensemble_data_{}.csv'. format(version), dest1)
            counter = counter + 1

        for epoch in range(0, num_epochs, 1):
            epo = epoch + 1
            # name_weights = 'Train_model_weights_%s_{epoch:02d}.h5' % name_file_rede
            # print('\n ** TESTE Removing WEIGHTS: ' 'Train_model_weights_{}_0{}.h5'. format(name_file_rede, epo))
            weicounter = remove_weights_ensemble(weicounter, name_file_rede, epoch)
            if epoch < 10:
                # Números menores que 10
                if os.path.exists('./Train_model_weights_{}_0{}.h5'. format(name_file_rede, epo)):
                    os.remove('./Train_model_weights_{}_0{}.h5'. format(name_file_rede, epo))
                    weicounter = weicounter + 1
            else:
                # Números maiores que 10
                if os.path.exists('./Train_model_weights_{}_{}.h5'. format(name_file_rede, epo)):
                    os.remove('./Train_model_weights_{}_{}.h5'. format(name_file_rede, epo))
                    weicounter = weicounter + 1

    print('\n ** Done. {} files moved, '. format(counter), '{} weights removed.'. format(weicounter))


def remove_weights_ensemble(weicounter, name_file_rede, epoch):
    epo = epoch + 1
    if epo < 10:
        # name_weights_resnet = 'Train_model_weights_%s_resnet_{epoch:02d}.h5' % name_file_rede
        # Resnet menores que 10
        if os.path.exists('Train_model_weights_{}_resnet_0{}.h5'. format(name_file_rede, epo)):
            os.remove('Train_model_weights_{}_resnet_0{}.h5'. format(name_file_rede, epo))
            weicounter = weicounter + 1
        # name_weights_efn = 'Train_model_weights_%s_effnet_{epoch:02d}.h5' % name_file_rede
        # Effnet maiores que 10
        if os.path.exists('Train_model_weights_{}_effnet_0{}.h5'. format(name_file_rede, epo)):
            os.remove('Train_model_weights_{}_effnet_0{}.h5'. format(name_file_rede, epo))
            weicounter = weicounter + 1

    else:
        # Resnet maiores que 10
        if os.path.exists('Train_model_weights_{}_resnet_{}.h5'. format(name_file_rede, epo)):
            os.remove('Train_model_weights_{}_resnet_{}.h5'. format(name_file_rede, epo))
            weicounter = weicounter + 1

        # Effnet maiores que 10
        if os.path.exists('Train_model_weights_{}_effnet_{}.h5'. format(name_file_rede, epo)):
            os.remove('Train_model_weights_{}_effnet_{}.h5'. format(name_file_rede, epo))
            weicounter = weicounter + 1

    return weicounter
